import 'package:flutter/material.dart';
import 'Cell.dart';

class CellWidget extends StatelessWidget {
  final Cell cell;
  final VoidCallback onTap;

  const CellWidget({Key? key, required this.cell, required this.onTap})
      : super(key: key);

  Color _getColor() {
    switch (cell.state) {
      case CellState.inactive:
        return Colors.grey;
      case CellState.safe:
        return Colors.green;
      case CellState.bomb:
        return Colors.red;
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: _getColor(),
          borderRadius: BorderRadius.circular(4),
          border: Border.all(color: Colors.black54),
        ),
      ),
    );
  }
}