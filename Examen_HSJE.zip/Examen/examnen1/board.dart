import 'dart:math';
import 'Cell.dart';

class Board {
  final int size;
  late List<Cell> cells;
  late int bombIndex;

  Board(this.size) {
    _initialize();
  }

  void _initialize() {
    cells = List.generate(size * size, (index) => Cell(index: index));
    bombIndex = Random().nextInt(size * size);
    cells[bombIndex].isBomb = true;
  }

  void reset() {
    _initialize();
  }
}