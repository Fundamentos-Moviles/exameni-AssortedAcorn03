package com.example.examnen1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
