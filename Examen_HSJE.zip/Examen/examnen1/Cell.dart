enum CellState { inactive, safe, bomb }

class Cell {
  final int index;
  bool isBomb;
  CellState state;

  Cell({
    required this.index,
    this.isBomb = false,
    this.state = CellState.inactive,
  });
}
