import 'package:flutter/material.dart';
import 'board.dart';
import 'cell_widget.dart';
import 'Cell.dart';

void main() {
  runApp(MinesweeperApp());
}

class MinesweeperApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Buscaminas EXAMEN I',
      debugShowCheckedModeBanner: false,
      home: MinesweeperHomePage(),
    );
  }
}

class MinesweeperHomePage extends StatefulWidget {
  @override
  _MinesweeperHomePageState createState() => _MinesweeperHomePageState();
}

class _MinesweeperHomePageState extends State<MinesweeperHomePage> {
  static const int gridSize = 6;
  late Board board;
  bool gameOver = false;
  String message = "Buscaminas - Selecciona un cuadro";

  @override
  void initState() {
    super.initState();
    board = Board(gridSize);
  }

  void _onCellTap(int index) {
    if (gameOver) return;

    Cell cell = board.cells[index];
    if (cell.state != CellState.inactive) return;

    setState(() {
      if (cell.isBomb) {
        cell.state = CellState.bomb;
        gameOver = true;
        message = "¡Perdiste! Tocaste la bomba.";
        // Revelar todas las bombas
        for (var c in board.cells) {
          if (c.isBomb) c.state = CellState.bomb;
        }
      } else {
        cell.state = CellState.safe;
        message = "Continúa jugando...";
      }
    });
  }

  void _resetGame() {
    setState(() {
      board.reset();
      gameOver = false;
      message = "Buscaminas - Selecciona un cuadro";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Buscaminas EXAMEN I'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          SizedBox(height: 16),
          Text(
            'Nombre: Tu Nombre Completo',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 16),
          Text(
            message,
            style: TextStyle(fontSize: 16),
          ),
          SizedBox(height: 16),
          Expanded(
            child: GridView.builder(
              padding: EdgeInsets.all(16),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: gridSize,
                crossAxisSpacing: 8,
                mainAxisSpacing: 8,
              ),
              itemCount: board.cells.length,
              itemBuilder: (context, index) {
                return CellWidget(
                  cell: board.cells[index],
                  onTap: () => _onCellTap(index),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: ElevatedButton.icon(
              icon: Icon(Icons.refresh),
              label: Text('Reiniciar Juego'),
              onPressed: _resetGame,
              style: ElevatedButton.styleFrom(
                minimumSize: Size(double.infinity, 48),
              ),
            ),
          ),
        ],
      ),
    );
  }
}